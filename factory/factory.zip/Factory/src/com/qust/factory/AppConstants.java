package com.qust.factory;

public class AppConstants {
	public static final String JDBC_URL = "jdbc:sqlite:factory.db";
	public static final String JDBC_USERNAME = "test";
	public static final String JDBC_PASSWORD = "test";
	public static final String JDBC_DRIVER = "org.sqlite.JDBC";
}
