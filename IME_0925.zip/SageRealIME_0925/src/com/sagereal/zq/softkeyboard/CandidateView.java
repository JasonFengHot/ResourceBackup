/*
 * Copyright (C) 2008-2009 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.sagereal.zq.softkeyboard;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.List;
import com.sagereal.zq.softkeyboard.R;
//Redmine67256 zhangqi modified for InputMethod 2016/10/24:begin
import java.util.Collections;
import android.view.WindowManager;
//Redmine67256 zhangqi modified for InputMethod 2016/10/24:end

public class CandidateView extends View {
	private static final int OUT_OF_BOUNDS = -1;
	private SoftKeyboard mService;
	private List<String> mSuggestions;
	private Drawable mSelectionHighlight;
	private boolean mTypedWordValid;
	private Rect mBgPadding;
	//Redmine92698 zhangqi modified for MAX_SUGGESTIONS 2017/05/03:begin
	private static final int MAX_SUGGESTIONS = 64;
	//Redmine92698 zhangqi modified for MAX_SUGGESTIONS 2017/05/03:end
	private static final int SCROLL_PIXELS = 20;
	private int[] mWordWidth = new int[MAX_SUGGESTIONS];
	private int[] mWordX = new int[MAX_SUGGESTIONS];
	//Redmine67256 zhangqi modified for InputMethod 2016/10/24:begin
	private static final int X_GAP = 8;
	//Redmine67256 zhangqi modified for InputMethod 2016/10/24:end
	private static final List<String> EMPTY_LIST = new ArrayList<String>();
	private int mColorNormal;
	private int mColorRecommended;
	private int mColorOther;
	private int mVerticalPadding;
	private Paint mPaint;
	private boolean mScrolled;
	private int mTotalWidth;
	private WindowManager windowManager;
	private int screenWidth;
	private Paint rectPaint;
	/**
	 * Construct a CandidateView for showing suggested words for completion.
	 * 
	 * @param context
	 * @param attrs
	 */
	@SuppressWarnings("deprecation")
	public CandidateView(Context context) {
		super(context);
		mSelectionHighlight = context.getResources().getDrawable(android.R.drawable.list_selector_background);
		mSelectionHighlight.setState(new int[] { android.R.attr.state_enabled, android.R.attr.state_focused, android.R.attr.state_window_focused, android.R.attr.state_pressed });
		Resources r = context.getResources();
		setBackgroundColor(r.getColor(R.color.candidate_background));
		mColorNormal = r.getColor(R.color.candidate_normal);
		mColorRecommended = r.getColor(R.color.candidate_recommended);
		mColorOther = r.getColor(R.color.candidate_other);
		mVerticalPadding = r.getDimensionPixelSize(R.dimen.candidate_vertical_padding);
		windowManager = (WindowManager)context.getSystemService(Context.WINDOW_SERVICE);
		screenWidth = windowManager.getDefaultDisplay().getWidth();
		mPaint = new Paint();
		mPaint.setColor(mColorNormal);
		mPaint.setAntiAlias(true);
		mPaint.setTextSize(r.getDimensionPixelSize(R.dimen.candidate_font_height));
		mPaint.setStrokeWidth(0);
		setHorizontalFadingEdgeEnabled(true);
		setWillNotDraw(false);
		setHorizontalScrollBarEnabled(false);
		setVerticalScrollBarEnabled(false);
		rectPaint = new Paint();
		rectPaint.setColor(0xffFEBC23);
	}
	/**
	 * A connection back to the service to communicate with the text field
	 * 
	 * @param listener
	 */
	public void setService(SoftKeyboard listener) {
		mService = listener;
	}
	@Override
	public int computeHorizontalScrollRange() {
		return mTotalWidth;
	}
	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		int measuredWidth = resolveSize(50, widthMeasureSpec);
		// Get the desired height of the icon menu view (last row of items does
		// not have a divider below)
		Rect padding = new Rect();
		mSelectionHighlight.getPadding(padding);
		final int desiredHeight = ((int) mPaint.getTextSize()) + mVerticalPadding + padding.top + padding.bottom;
		// Maximum possible width and desired height
		setMeasuredDimension(measuredWidth, resolveSize(desiredHeight, heightMeasureSpec));
	}
	private int mSelection = 0;
	public int getSelection() {
		return this.mSelection;
	}
	//Redmine67256 zhangqi modified for InputMethod 2016/10/24:begin
	public void setSelection(int selection) {
        if (mSuggestions == null) {
            return;
        }
        if (selection < 0) {
            this.mSelection = mSuggestions.size() - 1;
        } else if (selection > mSuggestions.size() - 1) {
            this.mSelection = 0;
        } else {
            this.mSelection = selection;
        }
		invalidate();
	}
	//Redmine67256 zhangqi modified for InputMethod 2016/10/24:end
	public String getSelectedWord() {
		if (mSuggestions == null || mSelection > mSuggestions.size() - 1) {
			return "";
		}
		return mSuggestions.get(mSelection);
	}
	/**
	 * If the canvas is null, then only touch calculations are performed to pick the target candidate.
	 */
	@Override
	protected void onDraw(Canvas canvas) {
		if (canvas != null) {
			super.onDraw(canvas);
		}
		mTotalWidth = 0;
		if (mSuggestions == null)
			return;
		if (mBgPadding == null) {
			mBgPadding = new Rect(0, 0, 0, 0);
			if (getBackground() != null) {
				getBackground().getPadding(mBgPadding);
			}
		}
		int x = 0;
		final int count = mSuggestions.size();
		final int height = getHeight();
		final Rect bgPadding = mBgPadding;
		final Paint paint = mPaint;
		final int scrollX = getScrollX();
		final boolean scrolled = mScrolled;
		final boolean typedWordValid = mTypedWordValid;
		final int y = (int) (((height - mPaint.getTextSize()) / 2) - mPaint.ascent());
		for (int i = 0; i < count; i++) {
			String suggestion = mSuggestions.get(i);
			float textWidth = paint.measureText(suggestion);
			final int wordWidth = (int) textWidth + X_GAP * 2;
			mWordX[i] = x;
			mWordWidth[i] = wordWidth;
			paint.setColor(mColorNormal);
			if (canvas != null) {
				if ((i == 1 && !typedWordValid) || (i == mSelection && typedWordValid)) {
					paint.setFakeBoldText(true);
					int startX = 0;
					for (int j = 0; j < mSelection; j++) {
					    startX += mWordWidth[j];
					}
					paint.setColor(mColorRecommended);
					//draw focused rect
                    canvas.drawRect(x + 1, 0, x + wordWidth, 50, rectPaint);
				} else if (i != 0) {
					paint.setColor(mColorOther);
				}
				canvas.drawText(suggestion, x + X_GAP, y, paint);
				paint.setColor(mColorOther);
				canvas.drawLine(x + wordWidth + 0.5f, bgPadding.top, x + wordWidth + 0.5f, height + 1, paint);
				paint.setFakeBoldText(false);
			}
			x += wordWidth;
		}
		mTotalWidth = x;
		scrollToTarget();
	}
	private void scrollToTarget() {
		if (mTotalWidth <= screenWidth) {
		    return;
		}
		int targetX = mWordX[mSelection] + mWordWidth[mSelection] / 2 - screenWidth / 2;
		if (targetX < 0) {
		    targetX = 0;
		}
		if (mTotalWidth - targetX <= screenWidth) {
		    targetX = mTotalWidth - screenWidth;
		}
		scrollTo(targetX, getScrollY());
	}
	//Redmine67256 zhangqi modified for InputMethod 2016/10/24:begin
    //list compare begin
    public <T extends Comparable<T>> boolean compare(List<T> a, List<T> b) {
        if(a == null || b == null){
            return false;
        }
        List<T> aa = new ArrayList<T>(a);
        List<T> bb = new ArrayList<T>(b);
        if(aa.size() != bb.size()){
            return false;
        }
        java.util.Collections.sort(aa);
        java.util.Collections.sort(bb);
        for(int i = 0; i < aa.size(); i++){
            if(!aa.get(i).equals(bb.get(i))){
                return false;
            }
        }
        return true;
    }
    //list compare end
    public void setSuggestions(List<String> suggestions, boolean completions, boolean typedWordValid) {
        if(compare(mSuggestions, suggestions)){
            //setSelection(getSelection() + 1);
            return;
        }
        clear();
        if (suggestions != null) {
            mSuggestions = new ArrayList<String>(suggestions);
        }
        mTypedWordValid = typedWordValid;
        scrollTo(0, 0);
        // Compute the total width
        onDraw(null);
        invalidate();
        requestLayout();
    }
    //Redmine67256 zhangqi modified for InputMethod 2016/10/24:end
	public void clear() {
		mSuggestions = EMPTY_LIST;
		//Redmine67256 zhangqi modified for InputMethod 2016/10/24:begin
		mSelection = 0;
		//Redmine67256 zhangqi modified for InputMethod 2016/10/24:end
		invalidate();
	}
}
